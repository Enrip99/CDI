#ifndef DIMENSIONSIO_H
#define DIMENSIONSIO_H

#define numBytes 4094
#define numBits ( numBytes * 8 )
#define bytesPadding 2
#define midaArray ( numBytes + bytesPadding )
#define bytesDiferents 256
#define midaBuffer 4096

#endif